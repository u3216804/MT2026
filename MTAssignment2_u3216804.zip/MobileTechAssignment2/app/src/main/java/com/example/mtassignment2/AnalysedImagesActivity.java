package com.example.mtassignment2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class AnalysedImagesActivity extends AppCompatActivity {
    private final List<DatabaseResult> databaseResults = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_analysed_images);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        DatabaseAdapter adapter = new DatabaseAdapter(AnalysedImagesActivity.this, R.layout.analysed_list_item, databaseResults);

        ListView databaseListView = findViewById(R.id.listView);
        databaseListView.setAdapter(adapter);

        DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("Storage");

        dbRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                DatabaseResult result = snapshot.getValue(DatabaseResult.class);
                if (result != null) {
                    databaseResults.add(result);
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                DatabaseResult result = snapshot.getValue(DatabaseResult.class);
                if (result != null) {
                    databaseResults.add(result);
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                DatabaseResult result = snapshot.getValue(DatabaseResult.class);
                if (result != null) {
                    for (int i = 0; i < databaseResults.size(); i++) {
                        if (databaseResults.get(i).getFilename().equals(result.getFilename())) {
                            databaseResults.remove(i);
                            adapter.notifyDataSetChanged();
                            break;
                        }
                    }
                }
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        // click listener for list view items
        databaseListView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        DatabaseResult res = databaseResults.get(position);
                        Intent intent = new Intent(view.getContext(), DatabaseItemActivity.class);
                        intent.putExtra("filename", res.getFilename());
                        intent.putExtra("reader", res.getReader());
                        intent.putExtra("text", res.getText());
                        intent.putExtra("uri", res.loadImageFromGallery(view.getContext()));
                        startActivity(intent);
                    }
                });

        Button addButton = findViewById(R.id.addButton);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AnalysedImagesActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}