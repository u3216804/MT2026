package com.example.mtassignment2;

import static java.security.AccessController.getContext;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DatabaseAdapter extends ArrayAdapter<DatabaseResult> {
    private List<DatabaseResult> items = new ArrayList<>();
    public DatabaseAdapter(@NonNull Context context, int resource, @NonNull List<DatabaseResult> objects) {
        super(context, resource, objects);
        items = objects;
    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.analysed_list_item, parent, false);
        }
        DatabaseResult item = items.get(position);
        ImageView image = convertView.findViewById(R.id.imageViewListItem);
        image.setImageURI(item.loadImageFromGallery(convertView.getContext()));
        TextView textViewItem = convertView.findViewById(R.id.textViewItem);
        textViewItem.setText(item.getReader());

        // alternate background colours
        int backgroundColour = Color.WHITE;
        if (position % 2 == 0) {
            backgroundColour = Color.LTGRAY;
        }
        convertView.setBackgroundColor(backgroundColour);

        return convertView;
    }
}
