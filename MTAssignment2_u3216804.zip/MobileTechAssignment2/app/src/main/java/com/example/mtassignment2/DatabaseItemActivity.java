package com.example.mtassignment2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DatabaseItemActivity extends AppCompatActivity {
    private String filename;
    private String reader;
    private String text;
    private Uri imageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_database_item);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            filename = extras.getString("filename");
            reader = extras.getString("reader");
            text = extras.getString("text");
            imageUri = extras.getParcelable("uri", Uri.class);
        }
        else {
            finish();
        }

        TextView readerTextView = findViewById(R.id.mlReaderTextView);
        readerTextView.setText(reader);

        TextView textView = findViewById(R.id.mlTextView);
        textView.setText(text);

        ImageView imageView = findViewById(R.id.mlImageView);
        imageView.setImageURI(imageUri);

        DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("Storage");

        Button editButton = findViewById(R.id.itemEditButton);
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), EditActivity.class);
                intent.putExtra("new_entry", false);
                intent.putExtra("filename", filename);
                intent.putExtra("reader", reader);
                intent.putExtra("text", text);
                intent.putExtra("uri", imageUri);
                startActivity(intent);
            }
        });

        Button deleteButton = findViewById(R.id.itemDeleteButton);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbRef.child(filename).removeValue();
                finish();
            }
        });

        Button cancelButton = findViewById(R.id.itemCancelButton);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}