package com.example.mtassignment2;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.io.OutputStream;
import java.time.LocalDateTime;

public class EditActivity extends AppCompatActivity {
    private String filename;
    private String reader;
    private String text;
    private Uri imageUri;
    private ImageView editorImage;
    private boolean newEntry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            newEntry = extras.getBoolean("new_entry");
            filename = extras.getString("filename");
            reader = extras.getString("reader");
            text = extras.getString("text");
            imageUri = extras.getParcelable("uri", Uri.class);
        }
        else {
            finish();
        }

        TextInputEditText readerBox = findViewById(R.id.readerInputEditText);
        readerBox.setText(reader);
        TextInputEditText textBox = findViewById(R.id.textInputEditText);
        textBox.setText(text);
        editorImage = findViewById(R.id.editImage);
        editorImage.setImageURI(imageUri);

        Button saveButton = findViewById(R.id.editSaveButton);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (newEntry) {
                    Bitmap bitmap = getBitmapFromUri(imageUri);
                    if (bitmap != null) {
                        String currentDateTime = LocalDateTime.now().toString();
                        filename = currentDateTime.replaceAll("\\D+", "");
                        imageUri = saveImageToGallery(bitmap, filename, EditActivity.this);
                        editorImage.setImageURI(imageUri);
                    }
                }

                reader = readerBox.getText().toString();
                text = textBox.getText().toString();

                DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("Storage").child(filename);
                dbRef.setValue(new DatabaseResult(filename, reader, text));

                Intent intent = new Intent(view.getContext(), AnalysedImagesActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private Bitmap getBitmapFromUri(Uri uri) {
        try {
            ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
            return ImageDecoder.decodeBitmap(source);
        } catch (IOException e) {
            return null;
        }
    }

    private Uri saveImageToGallery(Bitmap bitmap, String fileName, Context context) {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES);
        Uri uri = context.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        try {
            OutputStream outputStream = context.getContentResolver().openOutputStream(uri);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
            outputStream.flush();
            outputStream.close();
        } catch (IOException ignored) {}

        return uri;
    }
}