package com.example.mtassignment2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.net.URI;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageView barcodeReaderImage = findViewById(R.id.barcodeReaderImageView);
        barcodeReaderImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ReaderActivity.class);
                intent.putExtra("type", "barcode");
                startActivity(intent);
                finish();
            }
        });

        ImageView contentReaderImage = findViewById(R.id.contentReaderImageView);
        contentReaderImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ReaderActivity.class);
                intent.putExtra("type", "content");
                startActivity(intent);
                finish();
            }
        });

        ImageView textReaderImage = findViewById(R.id.textReaderImageView);
        textReaderImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ReaderActivity.class);
                intent.putExtra("type", "text");
                startActivity(intent);
                finish();
            }
        });

        Button listImagesButton = findViewById(R.id.imagesListButton);
        listImagesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AnalysedImagesActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}