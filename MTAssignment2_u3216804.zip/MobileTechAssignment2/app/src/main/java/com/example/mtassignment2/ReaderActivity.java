package com.example.mtassignment2;

import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.IOException;
import java.util.List;
import java.util.Objects;

public class ReaderActivity extends AppCompatActivity {

    private String readerType = "barcode";
    private Uri imageUri;
    private TextView titleTextView;
    private TextView descriptionTextView;
    private ImageView imageView;
    private Button editButton;
    private ActivityResultLauncher<Intent> imageResultLauncher;
    private String reader = "No reader selected.";
    private String text = "";
    private String filename = "NULL";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_reader);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // retrieve reader type
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            readerType = extras.getString("type");
        }

        // store handles to views
        titleTextView = findViewById(R.id.titleTextView);
        descriptionTextView = findViewById(R.id.descriptionTextView);
        ImageView imageView = findViewById(R.id.editImage);
        editButton = findViewById(R.id.editButton);

        // set initial image
        if (Objects.equals(readerType, "text")) {
            imageView.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.text));
        }
        else if (Objects.equals(readerType, "content")) {
            imageView.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.content));
        }
        else { // barcode
            imageView.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.barcode));
        }

        // initialize image result callback
        imageResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                            @Override
                            public void onActivityResult(ActivityResult result) {
                                if (result.getResultCode() == RESULT_OK) {
                                    if (result.getData() != null && result.getData().getData() != null) {
                                        imageUri = result.getData().getData();
                                    }

                                    imageView.setImageURI(imageUri);
                                    processImage();
                                }
                            }
                        });

        Button openCameraButton = findViewById(R.id.openCameraButton);
        openCameraButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkCameraPermission()) {
                    openCamera();
                }
            }
        });

        Button loadImageButton = findViewById(R.id.loadImageButton);
        loadImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadImage();
            }
        });

        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageView.setImageURI(imageUri);
                Intent intent = new Intent(view.getContext(), EditActivity.class);
                intent.putExtra("new_entry", true);
                intent.putExtra("filename", filename);
                intent.putExtra("reader", reader);
                intent.putExtra("text", text);
                intent.putExtra("uri", imageUri);
                startActivity(intent);
                //finish();
            }
        });
    }

    private boolean checkCameraPermission() {
        String permission = android.Manifest.permission.CAMERA;
        boolean cameraAllowed = ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED;
        if (!cameraAllowed) { // prompt for permission, if not already granted.
            ActivityCompat.requestPermissions(this, new String[]{permission}, 3000);
        }
        return cameraAllowed;
    }

    private void openCamera() {
        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        imageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new ContentValues());
        takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        imageResultLauncher.launch(takePhotoIntent);
    }

    private void loadImage() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        imageResultLauncher.launch(galleryIntent);
    }

    private void processImage() {
        descriptionTextView.setText("");

        InputImage image = null;
        try {
            image = InputImage.fromFilePath(getBaseContext(), imageUri);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        if (Objects.equals(readerType, "text")) {
            reader = "Text Reader";
            TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            Task<Text> result = recognizer.process(image)
                            .addOnSuccessListener(new OnSuccessListener<Text>() {
                                @Override
                                public void onSuccess(Text visionText) {
                                    descriptionTextView.append(Html.fromHtml("<font><b>Extracted text:</b></font><br>", Html.FROM_HTML_MODE_LEGACY));
                                    String result = visionText.getText();
                                    if (result.length() > 1) {
                                        descriptionTextView.append(" " + result + "\n");
                                        editButton.setVisibility(View.VISIBLE);
                                        text = descriptionTextView.getText().toString();
                                        //submitToDatabase(imageFilename, reader, descriptionTextView.getText().toString());
                                    }
                                    else {
                                        descriptionTextView.append(" No text found.\n");
                                    }
                                }
                            })
                            .addOnFailureListener(
                                    new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            descriptionTextView.setText("Failed");
                                        }
                                    });
        }
        else if (Objects.equals(readerType, "content")) {
            reader = "Content Reader";
            ImageLabeler labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS);
            labeler.process(image)
                    .addOnSuccessListener(
                            new OnSuccessListener<List<ImageLabel>>() {
                                @Override
                                public void onSuccess(List<ImageLabel> labels) {
                                    if (labels.size() == 0) {
                                        descriptionTextView.append("Nothing found in the image\n");
                                        return;
                                    }
                                    descriptionTextView.append(Html.fromHtml("<font><b>Recognised image content:</b></font><br>", Html.FROM_HTML_MODE_LEGACY));
                                    int counter = 1;
                                    for (ImageLabel label : labels) {
                                        String result = label.getText();
                                        float confidence = label.getConfidence();
                                        descriptionTextView.append(" " + counter + ". " + result + " (" + String.format("%.1f", confidence * 100.0f) + "% confidence)\n");
                                        counter++;
                                    }
                                    editButton.setVisibility(View.VISIBLE);
                                    text = descriptionTextView.getText().toString();
                                    //submitToDatabase(imageFilename, reader, descriptionTextView.getText().toString());
                                }
                            })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            descriptionTextView.setText("Failed");
                        }
                    });
        }
        else { // barcode
            reader = "Barcode Reader";
            BarcodeScannerOptions options = new BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS).build();
            BarcodeScanner scanner = BarcodeScanning.getClient(options);
            Task<List<Barcode>> result = scanner.process(image)
                    .addOnSuccessListener(new OnSuccessListener<List<Barcode>>() {
                        @Override
                        public void onSuccess(List<Barcode> barcodes) {
                            descriptionTextView.append(Html.fromHtml("<font><b>Detected barcode:</b></font><br>", Html.FROM_HTML_MODE_LEGACY));
                            String result = "";
                            for (Barcode barcode : barcodes) {
                                result = barcode.getRawValue();
                                descriptionTextView.append(result + "\n");
                            }
                            if (result.length() < 2) {
                                descriptionTextView.append(" Barcode not found.\n");
                            }
                            else {
                                editButton.setVisibility(View.VISIBLE);
                                text = descriptionTextView.getText().toString();
                                //submitToDatabase(imageFilename, reader, );
                            }
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            descriptionTextView.setText("Failed");
                        }
                    });
        }

        titleTextView.setText(reader);
    }
}